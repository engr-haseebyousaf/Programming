<!-- General JS Scripts -->
<script src="assets/js2/app.min.js"></script>
<!-- JS Libraies -->
<script src="assets/js2/apexcharts.min.js"></script>
<!-- Page Specific JS File -->
<script src="assets/js2/index.js"></script>
<!-- Coctact Files  -->
<script src="http://maps.google.com/maps/api/js?key=AIzaSyB55Np3_WsZwUQ9NS7DP-HnneleZLYZDNw&amp;sensor=true"></script>
<script src="assets/js2/gmaps.js"></script>
<!-- Page Specific JS File -->
<script src="assets/js2/contact.js"></script>
<!-- Export table  -->
<script src="assets/js2/datatables.min.js"></script>
<script src="assets/js2/datatables.js"></script>

<!-- Template JS File -->
<script src="assets/js2/scripts.js"></script>
<!-- Custom JS File -->
<script src="assets/js2/custom.js"></script>
<!-- Bootstrap 5 -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>