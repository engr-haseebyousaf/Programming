<?php
$conn = mysqli_connect("localhost", "root", "", "event-management") or die("Connection Failed : ");
?>